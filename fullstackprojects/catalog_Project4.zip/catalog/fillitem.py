from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from database_setup import Base, CourseDB, User

engine = create_engine('sqlite:///CourseCatalog.db')
# Bind the engine to the metadata of the Base class so that the
# declaratives can be accessed through a DBSession instance
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
# A DBSession() instance establishes all conversations with the database
# and represents a "staging zone" for all the objects loaded into the
# database session object. 

session = DBSession()

# Create  user
User1 = User(name="admin", email="asthajindal231@gmail.com")
session.add(User1)
session.commit()

# Course data
course1 = CourseDB(courseName="Intro to programming",
               authorName="xyz",
               coverUrl="""http://guyhaas.com/bfoit/itp/images/Programming_Wordle.jpg""",
               description="hello", category="Website", user_id=1)

session.add(course1)
session.commit()

course2 = CourseDB(courseName="Front end developer",
               authorName="pqr",
               coverUrl="""http://vijayy.com/img/portfolio/html.png""",
               description="hello", category="Website", user_id=1)

session.add(course2)
session.commit()

course3 =CourseDB(courseName="Basics of anderoid",
               authorName="qvw",
               coverUrl="""https://www.android.com/static/img/history/features/feature_donut_2.png""",
               description="hello", category="Anderoid", user_id=1)

session.add(course3)
session.commit()

course4 = CourseDB(courseName="Basic of GitHub",
               authorName="uvw",
               coverUrl="""https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRqcIBlLPtiYLQDeWgtYfP4myB0Qb3-8wurREj1xJXiPwisUvtR""",
               description="hello", category="GitHub", user_id=1)

session.add(course4)
session.commit()

course5 = CourseDB(courseName=" C Programming",
               authorName="uwe",
               coverUrl="""https://lh3.googleusercontent.com/3gI9l3yQynt2cj1MFdTZbaYE0VK056s-lvE4iejCCZQ1_-S8v3ZGDCPsIhtQsOB8Kb8i=w300""",
               description="hello", category="Coding", user_id=1)

session.add(course5)
session.commit()


print "available courses added!"
