#H1 Project Title:
#H3 Movie Trailer Website
```
shows some movie names with images and click images to see trailer
```

#H2 Installation/Quickstart:
#H4 Project includes:
```
entertainment_center.py,fresh-tomatoes.py,media.py,fresh-tomatoes.html
```
#H5 To generate fresh-tomatoes.html by running and executing python script:
1. First enter in file folder using cd /path/to/project
2. Then run the python script using python file.py here python entertainment_center.py
#H6 Running fresh-tomatoes.html
1. open file fresh-tomatoes.html; on your favourite browser
2. click the image of movie to see trailer 

